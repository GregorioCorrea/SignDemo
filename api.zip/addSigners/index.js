const { table } = require('../shared/storage');
const { issueToken } = require('../shared/tokens');
const { v4: uuidv4 } = require('uuid');

module.exports = async function (context, req) {
  try {
    const { agreementId, signers, frontBaseUrl } = req.body || {};
    if (!agreementId || !Array.isArray(signers) || !frontBaseUrl) {
      return { status: 400, jsonBody: { ok: false, error: 'Datos inválidos' } };
    }

    const Signers = table('Signers');
    const links = [];

    for (const s of signers) {
      const signerId = uuidv4();

      await Signers.createEntity({
        partitionKey: agreementId,
        rowKey: signerId,
        Email: s.email,
        Name: s.name,
        Status: 'PENDING',
        order: s.order ?? 0
      });

      // token válido por 2 horas
      const token = issueToken({ agreementId, signerId, role: 'signer' }, 120);

      links.push({
        name: s.name,
        email: s.email,
        token, // <= devuelvo el token crudo
        url: `${frontBaseUrl}/sign.html?token=${encodeURIComponent(token)}`
      });
    }

    return {
      status: 200,
      jsonBody: { ok: true, agreementId, links }
    };
  } catch (err) {
    context.log.error('addSigners error', err);
    return { status: 500, jsonBody: { ok: false, error: 'Error interno' } };
  }
};